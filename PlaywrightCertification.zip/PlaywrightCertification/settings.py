import os
import subprocess
from time import time

BASE_URL="https://www.lambdatest.com"
URI_PLAYGROUND="selenium-playground"
BASE_URL_TEST=f"{BASE_URL}/{URI_PLAYGROUND}"

LAMBDA_WSS="wss://cdp.lambdatest.com/playwright?capabilities="

username = os.getenv("LT_USERNAME")
access_key = os.getenv("LT_ACCESS_KEY")

PLAYWRIGHT_VERSION = str(subprocess.getoutput('playwright --version')).strip().split(" ")[1]

BROWSER_SETUP = [{"browser": "Chrome", "platformName": "Windows 10"},
                 {"browser": "MicrosoftEdge", "platformName": "macOS Sonoma"}]

# BROWSER_SETUP = ["Chrome", "MicrosoftEdge"]


timestamp = int(time())

CAPABILITY = {
                'browserName': "Chrome",
                'browserVersion': 'latest',
                'LT:Options': {
                        'platform': 'Windows 10',
                        'build': 'Build_PW',
                        'name': 'Testing Settings',
                        'user': username,
                        'accessKey': access_key,
                        'network': True,
                        'video': True,
                        'console': True,
                        'terminal': True,
                        'resolution': '1920x1080',
                }
        }