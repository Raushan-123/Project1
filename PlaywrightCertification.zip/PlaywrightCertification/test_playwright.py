import pytest
import re
import time
from playwright.sync_api import expect, sync_playwright
from pages import page_playground, page_simple_form_demo, page_drag_drop_sliders, page_input_form_submit


def test_scenario_1(browser):
    page = browser.new_page()

    # Page Objects instances
    playground_page = page_playground.PlaygroundPage(page)
    simple_form_demo_page = page_simple_form_demo.SimpleFormDemo(page)

    # Open Browser, goto site, select menu and confirm page url
    page.goto("/selenium-playground")
    playground_page.select_playground_menu("Simple Form Demo")
    expect(page).to_have_url(re.compile("simple-form-demo"))

    # Create a variable with message testing
    message = "Welcome to LambdaTest"

    # Enter message, click button Check Value and assert result
    simple_form_demo_page.enter_message(message)
    simple_form_demo_page.click_check_value()
    time.sleep(2)
    expect(simple_form_demo_page.text_message).to_have_text(message)


def test_scenario_2(browser):
    page = browser.new_page()

    # Page Object Instance
    playground_page = page_playground.PlaygroundPage(page)
    drag_drop_slider_page = page_drag_drop_sliders.DragDropSliders(page)

    # Open Browser, goto site, select menu
    page.goto("/selenium-playground")
    playground_page.select_playground_menu("Drag & Drop Sliders")

    # Select percent validation and do slider
    percent_select = "95"
    drag_drop_slider_page.do_slider("15", percent_select)

    # Confirm validation slider on range success field
    expect(drag_drop_slider_page.range_success).to_have_text(percent_select)


def test_scenario_3(browser):
    DATA_FORM_SUBMIT = {
        "Name": "Abc",
        "Email": "abc@gmail.com",
        "Password": "test123#",
        "Company": "DEF",
        "Website": "www.def.com",
        "country": "US",
        "City": "Clevalwood",
        "Address 1": "Block 21, Street 3",
        "Address 2": "near Cleval Park",
        "State": "MH",
        "Zip code": "111111"
    }

    page = browser.new_page()

    # Page Objects instances
    playground_page = page_playground.PlaygroundPage(page)
    input_form_submit_page = page_input_form_submit.InputFormSubmit(page)

    # Open Browser, goto site and select menu
    page.goto("/selenium-playground")
    playground_page.select_playground_menu("Input Form Submit")

    # Submit empty form and catch error message from DOM
    input_form_submit_page.submit_form()
    time.sleep(2)

    error_message = page.evaluate("""
                    () => {
                        // Get the first invalid required input field
                        const input = document.querySelector('input:required:invalid');
                        if (input) {
                            return input.validationMessage;  // Extract message from the browser
                        }
                        return null;
                    }
                """)

    # Assert different error messages on Chrome ('Please fill out this field.') & Edge ('Please fill in this field.')
    assert error_message == 'Please fill out this field.' or 'Please fill in this field.', f'Got error message as {error_message}'

    # Fill all fields and submit form
    input_form_submit_page.fill_all_fields(DATA_FORM_SUBMIT)
    input_form_submit_page.submit_form()

    # Assert message
    expect(input_form_submit_page.success_message).to_have_text(
        "Thanks for contacting us, we will get back to you shortly.")
