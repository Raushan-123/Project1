# Configure environment variables
1. Configure the environment variables on your machine with the LambdaTest credentials as:

export LT_USERNAME="<Username>"

export LT_ACCESS_KEY="<Access Key>"



# Local Installation and Run
1. Enter into project directory (PlaywrightCertification) as:

cd Playwright

cd PlaywrightCertification

2. Install dependencies as:

pip install -r requirements.txt

playwright install-deps

playwright install


# Run tests simultaneously as:
pytest test_playwright.py -n 3

OR

pytest test_playwright.py -n 6